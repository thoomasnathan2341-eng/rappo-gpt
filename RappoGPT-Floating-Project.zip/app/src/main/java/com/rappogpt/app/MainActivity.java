package com.rappogpt.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView status, memory;
    SharedPreferences prefs;
    static final int SPEECH=42, MIC=43, OVERLAY=44;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("memory",0);
        home();
    }
    TextView txt(String s,int n) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(n);
        t.setTextColor(Color.WHITE); t.setGravity(Gravity.CENTER); t.setPadding(12,12,12,12); return t;
    }
    Button btn(String s) { Button b=new Button(this); b.setText(s); return b; }

    void home() {
        root=new LinearLayout(this); root.setOrientation(1); root.setGravity(Gravity.CENTER);
        root.setPadding(20,20,20,20); root.setBackgroundColor(Color.rgb(14,18,38)); setContentView(root);
        root.addView(txt("🤖 RAPPO GPT",30));
        root.addView(txt("Your silent assistant",18));
        status=txt("Ready when you are.",16); root.addView(status);
        Button mic=btn("🎤 TAP TO SPEAK"); root.addView(mic); mic.setOnClickListener(v->listen());
        Button bubble=btn("🫧 ENABLE FLOATING BUBBLE"); root.addView(bubble); bubble.setOnClickListener(v->enableBubble());
        Button save=btn("🧠 SAVE A MEMORY"); root.addView(save); save.setOnClickListener(v->saveMemoryDialog());
        memory=txt("Memory: "+prefs.getString("memory","Nothing saved yet"),14); root.addView(memory);
        root.addView(txt("Starter version: speech transcription is not speaker identification.",12));
    }

    void enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
            startActivityForResult(i,OVERLAY);
        } else startBubble();
    }
    void startBubble() {
        try { startService(new Intent(this,FloatingBubbleService.class)); status.setText("Floating bubble enabled. You can return to other apps."); }
        catch(Exception e) { status.setText("Could not start bubble. Please try again."); }
    }
    void saveMemoryDialog() {
        EditText e=new EditText(this); e.setText(prefs.getString("memory",""));
        new AlertDialog.Builder(this).setTitle("Save a memory").setView(e)
            .setPositiveButton("Save",(d,w)->{prefs.edit().putString("memory",e.getText().toString()).apply(); memory.setText("Memory: "+prefs.getString("memory",""));})
            .setNegativeButton("Cancel",null).show();
    }
    void listen() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC); return;
        }
        try {
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            startActivityForResult(i,SPEECH);
        } catch(Exception e) { status.setText("Speech recognition unavailable."); }
    }
    protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d);
        if(r==OVERLAY) { if(Settings.canDrawOverlays(this)) startBubble(); else status.setText("Please allow Display over other apps to use the bubble."); }
        if(r==SPEECH&&c==RESULT_OK&&d!=null) {
            ArrayList<String>a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(a!=null&&!a.isEmpty()) command(a.get(0));
        }
    }
    void command(String s) {
        String c=s.toLowerCase(Locale.ROOT); status.setText("Heard: "+s);
        if(c.contains("open youtube")) open("https://youtube.com");
        else if(c.contains("search google for ")) { String q=s.substring(c.indexOf("search google for ")+18); open("https://www.google.com/search?q="+Uri.encode(q)); }
        else if(c.startsWith("remember ")) { String m=s.substring(9); prefs.edit().putString("memory",m).apply(); memory.setText("Memory: "+m); status.setText("Memory saved."); }
        else if(c.contains("what do you remember")) status.setText("Memory: "+prefs.getString("memory","Nothing saved yet"));
        else status.setText("Command received: "+s+" (try YouTube, Google search, or remember ...)");
    }
    void open(String u) { try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u))); } catch(Exception e) { status.setText("Could not open link."); } }
    public void onRequestPermissionsResult(int r,String[]p,int[]g) {
        super.onRequestPermissionsResult(r,p,g); if(r==MIC&&g.length>0&&g[0]==0) listen();
    }
}
