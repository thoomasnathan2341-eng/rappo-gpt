package com.rappogpt.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class FloatingBubbleService extends Service {
    private WindowManager wm;
    private View bubble;
    private WindowManager.LayoutParams params;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        TextView v=new TextView(this);
        v.setText("R"); v.setTextColor(Color.WHITE); v.setTextSize(24); v.setGravity(Gravity.CENTER);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(Color.rgb(93,63,211)); bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(3,Color.WHITE); v.setBackground(bg);
        int type=android.os.Build.VERSION.SDK_INT>=26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params=new WindowManager.LayoutParams(62,62,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START; params.x=24; params.y=180;
        v.setOnTouchListener(new View.OnTouchListener() {
            float downX,downY; int startX,startY; long downAt;
            public boolean onTouch(View view, MotionEvent e) {
                switch(e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; downAt=System.currentTimeMillis(); return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x=startX+(int)(e.getRawX()-downX); params.y=startY+(int)(e.getRawY()-downY);
                        try { wm.updateViewLayout(bubble,params); } catch(Exception ignored) {} return true;
                    case MotionEvent.ACTION_UP:
                        if(Math.abs(e.getRawX()-downX)<12 && Math.abs(e.getRawY()-downY)<12) {
                            Intent i=new Intent(FloatingBubbleService.this,MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(i);
                        }
                        return true;
                }
                return false;
            }
        });
        bubble=v;
        try { wm.addView(bubble,params); } catch(Exception e) { stopSelf(); }
    }
    @Override public void onDestroy() { if(wm!=null&&bubble!=null) try { wm.removeView(bubble); } catch(Exception ignored) {} super.onDestroy(); }
}
