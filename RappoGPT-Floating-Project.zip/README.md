# Rappo GPT — Floating Bubble Starter

This project adds a movable floating Rappo bubble to the starter Android app.

## Build
The GitHub Actions workflow builds a debug APK. Upload this ZIP to your repository root using the exact filename `RappoGPT-Android-Project-1.zip`, replacing the older ZIP. The existing workflow extracts that filename and builds the APK.

## Important
- The floating bubble requires the Android “Display over other apps” permission, which the user must enable in Settings.
- This is still a starter assistant: Android speech recognition transcribes speech, and commands are handled locally. It is not a connected large language model.
- Speech transcription is not secure voice identification. Do not rely on it to verify who is speaking.
