# Rappo GPT Android starter

A native Android starter app with a microphone button, silent text feedback, one locally saved memory, and simple YouTube/Google commands.

## Build APK using GitHub Actions
1. Upload the **contents** of this ZIP to the root of your GitHub repository, including the hidden `.github` folder.
2. Open **Actions** and select **Build Rappo GPT APK**. Tap **Run workflow**, or push to `main`.
3. Open the completed run and download artifact **RappoGPT-debug-apk**.
4. Extract that downloaded artifact ZIP to get `app-debug.apk`.

## Limitations
This starter is not yet a full AI assistant. It does not include a connected AI model, advanced long-term memory, PIN setup, voice biometrics, or broad app control. Android speech recognition transcribes speech but does not prove who is speaking.